## WebRTC Server

- Node.js server
- [Android client](https://github.com/matthewYang92/WebRtcAndroidClient)

## Install

It requires [node.js](http://nodejs.org/download/)

* git clone https://github.com/pchab/ProjectRTC.git
* cd ProjectRTC/
* npm install
* node app.js

The server will run on port 3000.

